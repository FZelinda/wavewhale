// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "WaveWhaleLAME",
    platforms: [.iOS(.v17), .macOS(.v13)],
    products: [.library(name: "WaveWhaleLAME", type: .dynamic, targets: ["CLame"])],
    targets: [
        .target(name: "CLame", publicHeadersPath: "include", cSettings: [
            .define("HAVE_CONFIG_H"), .headerSearchPath(".")
        ])
    ]
)
