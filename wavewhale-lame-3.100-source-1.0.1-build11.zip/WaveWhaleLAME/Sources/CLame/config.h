/* WaveWhale Apple-platform configuration, 2026-10-04.
 * Upstream encoder sources are unchanged. Decoder/assembly/fast-log disabled.
 */
#ifndef WAVEWHALE_LAME_CONFIG_H
#define WAVEWHALE_LAME_CONFIG_H
#define NDEBUG 1
#ifdef DEBUG
#undef DEBUG
#endif
#define STDC_HEADERS 1
#define HAVE_ERRNO_H 1
#define HAVE_FCNTL_H 1
#define HAVE_STDINT_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_LIMITS_H 1
#define HAVE_STRCHR 1
#define HAVE_MEMCPY 1
#define HAVE_STRERROR 1
#define HAVE_SNPRINTF 1
#define HAVE_VSNPRINTF 1
#define LAME_LIBRARY_BUILD 1
#define PACKAGE "lame"
#define PACKAGE_VERSION "3.100"
typedef float ieee754_float32_t;
typedef double ieee754_float64_t;
#endif
