# WaveWhale LAME source distribution

This package contains the exact LAME 3.100 encoder source and local build integration used for WaveWhale 1.0.1 (build 11). It contains no proprietary WaveWhale application source code, application binary, signing material or credentials.

## Contents and provenance

- `Sources/CLame/`: the encoder C source and headers used by the Swift package, including the local Apple-platform `config.h`.
- `Package.swift`: the exact dynamic Swift package build description.
- `upstream/lame-3.100.tar.gz`: the complete, unmodified upstream release archive, SHA-256 `ddfe36cab873794038ae2c1210557ad34857a4b6bdc515785d1da9e175b1da1e`.
- `source-manifest.json`: upstream source provenance and hashes, as retained in the application repository.
- `distribution-source-manifest.json`: SHA-256 values for the exact repository files included here.
- `COPYING` and `LICENSE`: unmodified upstream notices. `LGPL-2.1.txt` supplies the full later license text used for this distribution.
- `README.md`: the original local-integration documentation, retained for provenance. Its warning about release preparation describes obligations addressed through the separate source and replacement-material deliveries; it is not a claim of legal certification.

The upstream LAME encoder files are unchanged. The local additions are `Package.swift` and `Sources/CLame/config.h`. The encoder excludes the optional MPGLIB decoder, assembly and intrinsic paths; Apple frameworks perform decoding. The full upstream archive also contains components with their own licensing terms; those terms are preserved, and this notice does not relicense the optional GPL decoder or imply that it is included in the application binary.

## License selection and rights

The upstream encoder notices grant GNU Library General Public License version 2 or, at the recipient's option, any later version. For this distribution we exercise that option to apply GNU Lesser General Public License version 2.1; upstream recipients retain the original 2-or-later grant. The local package/configuration additions are also offered under LGPL-2.1-or-later. Copyright remains with the original authors and contributors. This package is provided without warranty, as specified in the licenses.

The application includes the LAME credit and license. Nothing in the WaveWhale application terms limits rights granted by the applicable open-source licenses. In particular, recipients may modify the combined work for their own use and reverse-engineer it for debugging those modifications as permitted by LGPL section 6. This permission does not grant access to or general redistribution rights in proprietary application source code. Apple's Standard EULA expressly preserves permissions granted by included open-source licenses: https://www.apple.com/legal/internet-services/itunes/dev/stdeula/ .

## Build and replace the library

For a host source build, run `swift build --package-path . --scratch-path ./local-build` in this directory. Building an iOS library uses the Apple iOS SDK and target architecture and must retain the public ABI and install name expected by the application.

Under the written offer included with the app and mirrored in `WRITTEN-OFFER.txt`, recipients can request the separate `wavewhale-1.0.1-build11-relink-kit.zip` without charge or proof of purchase. This kit supplies the unencrypted compiled application and scripts/instructions for building a changed library, replacing the bundled dynamic library, and signing the result for personal installation. Use that kit's README for the exact validated commands, platform requirements, signing limits and test evidence. No private application source, developer signing credentials or provisioning profiles are needed or supplied by this source archive. Apple's SDK and any personal device signing account are obtained independently from Apple.

Download the source and read the free written offer at https://fzelinda.github.io/wavewhale/open-source.html . Request the corresponding replacement materials through https://fzelinda.github.io/wavewhale/support.html . The complete compiled app is not publicly released before App Review approval. The source package filename is `wavewhale-lame-3.100-source-1.0.1-build11.zip`. The original LAME project is https://lame.sourceforge.io/ .

This package documents and supplies the technical distribution materials. It does not claim an independent legal opinion or certification.
