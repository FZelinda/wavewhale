# LAME 3.100 encoder for WaveWhale

This local Swift package compiles an unchanged subset of the official LAME 3.100 release into the **dynamic** `WaveWhaleLAME` product. Swift imports `CLame`. There are no downloaded prebuilt binaries or remote package dependencies. The complete original source archive is included in `upstream/`; `source-manifest.json` records its URL/SHA-256 and hashes for every included upstream file.

Official project: <https://lame.sourceforge.io/>. Official source mirror: <https://github.com/lameproject/lame>. Release archive: <https://downloads.sourceforge.net/project/lame/lame/3.100/lame-3.100.tar.gz>.

The encoder is Copyright © The LAME Project and its contributors, licensed under GNU Library GPL version 2 or later. The unmodified `COPYING` and `LICENSE` files are included. The GPL-licensed MPGLIB decoder is **not compiled**. Apple AVFoundation handles reading/decoding.

`Sources/CLame/config.h` is the Apple-platform configuration added on 2026-10-04. It selects standard C headers, floating-point typedefs and release-style assertions; the package disables the optional decoder, assembly, SIMD and approximate fast-log paths. No upstream C/header contents have been edited. `Package.swift` is the other local build addition. All library additions are provided under the same LGPL-2.0-or-later terms as the library.

The build target supports iOS 17+ and macOS 13+; source-based iOS support is verified through the WaveWhale Xcode target build, not inferred from upstream's platform list. A macOS source build is `swift build --package-path Vendor/WaveWhaleLAME --scratch-path work/lame-build` from the repository root. iOS uses the local package entry in `project.yml` and `xcodegen generate`.

## Redistribution

Local compilation and testing do not complete the requirements for distributing a linked application. Before a release containing LAME, retain the notice/license, publish the exact corresponding library source plus these build files, and supply the materials and permissions required for recipients to modify/relink the linked work under LGPL section 6. Dynamic linking alone does not establish compliance on a signed iOS app. A release needs a verified replacement/relink route and compatible end-user terms, including the required reverse-engineering exception. Do not interpret this local implementation as legal clearance or an approved App Store release.

The app includes the original license text and a LAME credit in the MP3 export screen. This source package and source archive must be included with the future compliance delivery. No new binary was submitted to Apple in this implementation task.
